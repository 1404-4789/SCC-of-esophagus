# tumor detection > 2023-11-16 5:03pm
https://universe.roboflow.com/southwestern-university-y7crb/tumor-detection-v4llz

Provided by a Roboflow user
License: CC BY 4.0

